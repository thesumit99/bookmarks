import { combineReducers } from 'redux'
import { bookmarkHandler } from './Bookmark.reducer';
export const rootReducer = combineReducers({
    bookmarkHandler
})
