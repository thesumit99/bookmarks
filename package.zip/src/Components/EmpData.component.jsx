 import React from "react"
 const EmpData=[
     {
     img:"https://picsum.photos/200/300?grayscale",
    name:"aniket bhoyar",
    id:1,
     profession:"Reactdevloper",
     description:"hi i am aniket sanjay bhoyar "
 },
     {
     img:"https://picsum.photos/200/300?grayscale",
    name:"Sumit hingaspure",
    id:2,
     profession:"React-js devloper",
     description:"hi i am sumit hingaspure bhoyar "
 },
     {
     img:"https://picsum.photos/200/300?grayscale",
    name:"sopan gajabhiye",
    id:3,
     profession:"Reactd-native evloper",
     description:"hi i am sopan gajabhiye bhoyar "
 },
     {
     img:"https://picsum.photos/200/300?grayscale",
    name:"amit shete",
    id:4,
     profession:"css devolper",
     description:"hi i am amit shete  "
 },
     {
     img:"https://picsum.photos/200/300?grayscale",
    name:"niraj kale",
    id:5,
     profession:"Html devloper",
     description:"hi i am niraj kale  "
 },
     {
     img:"https://picsum.photos/200/300?grayscale",
    name:"pratik ade",
    id:1,
     profession:"view developer",
     description:"hi i am pratik ade "
 }
]
export default EmpData;

