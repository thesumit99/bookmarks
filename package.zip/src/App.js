import React from 'react';
import Home from './Screens/Home.screen';
function App() {
  return (
    <div>
      <Home/>
    </div>
  );
}

export default App;
